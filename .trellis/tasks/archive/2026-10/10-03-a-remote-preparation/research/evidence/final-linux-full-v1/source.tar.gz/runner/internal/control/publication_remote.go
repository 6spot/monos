package control

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	protocol "monos.local/protocol"
	"monos.local/runner/internal/wire"
)

// Only current authenticated service connections can acquire transient grants.
// No returned credential is sent on WSS or exposed through the Agent protocol.
func (c *Client) publicationPost(ctx context.Context, path, name string, payload func(int64) any, out any) error {
	c.mu.Lock()
	inc, connected := c.inc, c.conn != nil && c.ready
	c.mu.Unlock()
	if !connected {
		return errors.New("publication connection unavailable")
	}
	raw, e := json.Marshal(payload(inc))
	if e != nil || len(raw) > 16384 {
		return errors.New("publication request unavailable")
	}
	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	req, e := http.NewRequestWithContext(ctx, http.MethodPost, strings.TrimRight(c.Config.Endpoint, "/")+path, bytes.NewReader(raw))
	if e != nil {
		return errors.New("publication request unavailable")
	}
	req.Header.Set("Authorization", "Bearer "+c.token)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Cache-Control", "no-store")
	resp, e := c.HTTP.Do(req)
	if e != nil {
		return errors.New("publication access unavailable")
	}
	defer resp.Body.Close()
	raw, e = io.ReadAll(io.LimitReader(resp.Body, 16385))
	if e != nil || len(raw) > 16384 || resp.StatusCode != http.StatusOK || !strings.Contains(strings.ToLower(resp.Header.Get("Cache-Control")), "no-store") {
		return errors.New("publication access unavailable")
	}
	if wire.Decode(name, raw, out) != nil {
		return errors.New("publication response unavailable")
	}
	c.mu.Lock()
	same := c.inc == inc && c.conn != nil && c.ready
	c.mu.Unlock()
	if !same {
		return errors.New("publication connection changed")
	}
	return nil
}

func (c *Client) PublicationPermission(ctx context.Context, r protocol.PublicationPrepareRequest) (protocol.PublicationPermissionResult, error) {
	var result protocol.PublicationPermissionResult
	_, digest, e := wire.Canonical(r)
	if e != nil {
		return result, e
	}
	e = c.publicationPost(ctx, "/v1/runner/publication-operations/"+url.PathEscape(r.OperationID)+"/permission", "PublicationPermissionResult", func(inc int64) any {
		return protocol.PublicationPermissionRequest{SchemaVersion: 1, Incarnation: inc, RequestDigest: digest}
	}, &result)
	if e != nil {
		return protocol.PublicationPermissionResult{}, e
	}
	if result.OperationID != r.OperationID || result.RequestDigest != digest {
		return protocol.PublicationPermissionResult{}, errors.New("publication permission mismatch")
	}
	return result, e
}

func (c *Client) PublicationAccess(ctx context.Context, r protocol.PublicationPushRequest, purpose protocol.Purpose, attempt string) (protocol.PublicationAccessResult, error) {
	var result protocol.PublicationAccessResult
	_, digest, e := wire.Canonical(r)
	if e != nil {
		return result, e
	}
	e = c.publicationPost(ctx, "/v1/runner/remote-preparation/"+url.PathEscape(r.OperationID)+"/access", "PublicationAccessResult", func(inc int64) any {
		return protocol.PublicationAccessRequest{SchemaVersion: 1, Incarnation: inc, RequestDigest: digest, Purpose: purpose, AttemptID: attempt}
	}, &result)
	if e != nil {
		return protocol.PublicationAccessResult{}, e
	}
	if result.OperationID != r.OperationID || result.RequestDigest != digest || result.ItemID != r.ItemID || result.AttemptID != attempt || result.Purpose != purpose || result.RemoteURL != r.RemoteURL || result.RepositoryID != r.RepositoryID || result.DeliveryRef != r.DeliveryRef || r.Prepared.Candidate == nil || result.CandidateHead != r.Prepared.Candidate.Head || !reflectPublicationHead(result.ExpectedHead, r.ExpectedHead) {
		return protocol.PublicationAccessResult{}, errors.New("publication access mismatch")
	}
	return result, e
}
func reflectPublicationHead(a, b *string) bool {
	return a == nil && b == nil || a != nil && b != nil && *a == *b
}
