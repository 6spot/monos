package host

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestRemotePreparationPrivateItemLockAndRetainedIntent(t *testing.T) {
	root := filepath.Join(publicationTestRoot(t), "remote")
	item, e := lockPublicationRemoteItem(context.Background(), root, "item")
	if e != nil {
		t.Fatal(e)
	}
	op, e := item.operationDirectory("operation")
	if e != nil {
		t.Fatal(e)
	}
	intent := map[string]any{"operation_id": "operation", "started": true}
	if e := savePublicationFile(filepath.Join(op, "intent.json"), intent); e != nil {
		t.Fatal(e)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 40*time.Millisecond)
	defer cancel()
	if blocked, e := lockPublicationRemoteItem(ctx, root, "item"); blocked != nil || !errors.Is(e, context.DeadlineExceeded) {
		t.Fatal("same item escaped physical exclusion", e)
	}
	other, e := lockPublicationRemoteItem(context.Background(), root, "other")
	if e != nil {
		t.Fatal("unrelated item blocked", e)
	}
	other.close()
	item.close()
	reopened, e := lockPublicationRemoteItem(context.Background(), root, "item")
	if e != nil {
		t.Fatal(e)
	}
	defer reopened.close()
	if _, e := readPublicationFile(filepath.Join(op, "intent.json")); e != nil {
		t.Fatal("lock release lost retained started intent", e)
	}
	if e := savePublicationFile(filepath.Join(op, "intent.json"), map[string]any{"operation_id": "replacement"}); e == nil {
		t.Fatal("conflicting intent replaced retained authority")
	}
	for path, mode := range map[string]os.FileMode{root: 0700, reopened.path: 0700, op: 0700, filepath.Join(reopened.path, "lock"): 0600, filepath.Join(op, "intent.json"): 0600} {
		info, e := os.Lstat(path)
		if e != nil || info.Mode().Perm() != mode {
			t.Fatal("remote primitive mode mismatch", path, e)
		}
	}
}

func TestRemotePreparationRejectsUnsafePrivateStorage(t *testing.T) {
	root := publicationTestRoot(t)
	unsafe := filepath.Join(root, "remote")
	if e := os.Mkdir(unsafe, 0755); e != nil {
		t.Fatal(e)
	}
	if item, e := lockPublicationRemoteItem(context.Background(), unsafe, "item"); e == nil || item != nil {
		t.Fatal("public remote journal admitted")
	}
	if item, e := lockPublicationRemoteItem(context.Background(), root, "../escape"); e == nil || item != nil {
		t.Fatal("item path traversal admitted")
	}
	itemPath := filepath.Join(root, "items", "symlink")
	if e := os.MkdirAll(itemPath, 0700); e != nil {
		t.Fatal(e)
	}
	target := filepath.Join(root, "target")
	if e := os.WriteFile(target, []byte("preserve"), 0600); e != nil {
		t.Fatal(e)
	}
	if e := os.Symlink(target, filepath.Join(itemPath, "lock")); e != nil {
		t.Fatal(e)
	}
	if item, e := lockPublicationRemoteItem(context.Background(), root, "symlink"); e == nil || item != nil {
		t.Fatal("symlink item lock admitted")
	}
	raw, _ := os.ReadFile(target)
	if string(raw) != "preserve" {
		t.Fatal("unsafe lock target changed")
	}
}

func remotePrimitivePush(t *testing.T, store, remote, hooks string, env []string, head, ref string) error {
	t.Helper()
	cmd := exec.Command("/usr/bin/git", "--no-replace-objects", "--git-dir="+store, "-c", "core.hooksPath="+hooks, "-c", "push.followTags=false", "push", "--porcelain", "--no-follow-tags", "--recurse-submodules=no", remote, head+":"+ref)
	cmd.Env = append(publicationGitEnvironment(), env...)
	raw, e := cmd.CombinedOutput()
	if e != nil {
		t.Logf("synthetic Git push rejected: %s", raw)
	}
	return e
}

func TestRemotePreparationFixedPrePushGuardInputAndTamper(t *testing.T) {
	root := publicationTestRoot(t)
	head, old := strings.Repeat("a", 40), strings.Repeat("b", 40)
	guard := publicationPushGuard{head, old, "refs/heads/delivery", "https://github.com/example/repo.git"}
	hooks, env, e := installPublicationPushGuard(context.Background(), root, guard)
	if e != nil {
		t.Fatal(e)
	}
	valid := head + " " + head + " " + guard.ref + " " + old + "\n"
	for _, tc := range []struct {
		name, input, destination string
		ok                       bool
	}{
		{"exact", valid, guard.destination, true},
		{"wrong_local", strings.Replace(valid, head, old, 1), guard.destination, false},
		{"wrong_new", strings.Replace(valid, head+" "+head, head+" "+old, 1), guard.destination, false},
		{"wrong_old", strings.Replace(valid, " "+old+"\n", " "+head+"\n", 1), guard.destination, false},
		{"wrong_ref", strings.Replace(valid, guard.ref, "refs/heads/other", 1), guard.destination, false},
		{"extra_update", valid + valid, guard.destination, false},
		{"extra_field", strings.TrimSuffix(valid, "\n") + " extra\n", guard.destination, false},
		{"no_newline", strings.TrimSuffix(valid, "\n"), guard.destination, false},
		{"nul", strings.Replace(valid, " ", "\x00 ", 1), guard.destination, false},
		{"bound", strings.Repeat("a", 4097) + "\n", guard.destination, false},
		{"wrong_destination", valid, "https://github.com/other/repo.git", false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			cmd := exec.Command(filepath.Join(hooks, "pre-push"), tc.destination, tc.destination)
			cmd.Env = append(publicationGitEnvironment(), env...)
			cmd.Stdin = strings.NewReader(tc.input)
			raw, e := cmd.CombinedOutput()
			if (e == nil) != tc.ok || len(raw) != 0 {
				t.Fatal("fixed guard input or output differs", e)
			}
		})
	}
	if e := os.WriteFile(filepath.Join(hooks, "pre-push"), []byte("#!/bin/sh\nexit 0\n"), 0700); e != nil {
		t.Fatal(e)
	}
	if _, _, e := installPublicationPushGuard(context.Background(), root, guard); e == nil {
		t.Fatal("tampered hook repaired or trusted")
	}
}

func TestRemotePreparationActualGitAdvertisedHeadAndReceiverCAS(t *testing.T) {
	work, base := scanFixture(t)
	resultTestWrite(t, work, "one", []byte("one"))
	middle := scanCommit(t, work)
	resultTestWrite(t, work, "two", []byte("two"))
	head := scanCommit(t, work)
	root := publicationTestRoot(t)
	remote := filepath.Join(root, "remote.git")
	resultTestGit(t, root, nil, "init", "--bare", "--quiet", remote)
	resultTestGit(t, remote, nil, "fetch", "--no-tags", work, base+":refs/heads/delivery", middle+":refs/monos/race")
	store := scanDir(t, work)
	guard := publicationPushGuard{head, base, "refs/heads/delivery", remote}
	hooks, env, e := installPublicationPushGuard(context.Background(), root, guard)
	if e != nil {
		t.Fatal(e)
	}
	// The unexpected middle is still an ancestor of head: ordinary FF alone
	// would accept it. The advertised expected-head guard must refuse it.
	resultTestGit(t, remote, nil, "update-ref", guard.ref, middle, base)
	if remotePrimitivePush(t, store, remote, hooks, env, head, guard.ref) == nil {
		t.Fatal("unexpected advertised ancestor accepted")
	}
	if resultTestGit(t, remote, nil, "rev-parse", guard.ref) != middle {
		t.Fatal("advertised mismatch mutated remote")
	}
	resultTestGit(t, remote, nil, "update-ref", guard.ref, base, middle)
	// A synthetic receiver-only hook moves the ref after advertisement. This
	// test hook is not used by production; receive-pack must reject old-OID CAS.
	receiverHook := filepath.Join(remote, "hooks", "pre-receive")
	script := "#!/bin/sh\nunset GIT_QUARANTINE_PATH GIT_OBJECT_DIRECTORY GIT_ALTERNATE_OBJECT_DIRECTORIES\n/usr/bin/git update-ref refs/heads/delivery " + middle + " " + base + "\n"
	if e := os.WriteFile(receiverHook, []byte(script), 0700); e != nil {
		t.Fatal(e)
	}
	if remotePrimitivePush(t, store, remote, hooks, env, head, guard.ref) == nil {
		t.Fatal("receiver CAS race accepted")
	}
	if resultTestGit(t, remote, nil, "rev-parse", guard.ref) != middle {
		t.Fatal("receiver race did not preserve foreign update")
	}
	if e := os.Remove(receiverHook); e != nil {
		t.Fatal(e)
	}
	guard.expected = middle
	_, env, e = installPublicationPushGuard(context.Background(), root, guard)
	if e != nil || remotePrimitivePush(t, store, remote, hooks, env, head, guard.ref) != nil {
		t.Fatal("exact nonforce FF push failed", e)
	}
	if resultTestGit(t, remote, nil, "rev-parse", guard.ref) != head {
		t.Fatal("successful push has wrong head")
	}
	guard.ref = "refs/heads/created"
	guard.expected = strings.Repeat("0", len(head))
	_, env, e = installPublicationPushGuard(context.Background(), root, guard)
	if e != nil || remotePrimitivePush(t, store, remote, hooks, env, head, guard.ref) != nil {
		t.Fatal("exact absent-head create failed", e)
	}
	resultTestGit(t, work, nil, "checkout", "--quiet", base)
	resultTestWrite(t, work, "sibling", []byte("sibling"))
	sibling := scanCommit(t, work)
	guard.head, guard.expected = sibling, head
	_, env, e = installPublicationPushGuard(context.Background(), root, guard)
	if e != nil || remotePrimitivePush(t, store, remote, hooks, env, sibling, guard.ref) == nil {
		t.Fatal("guard bypassed ordinary non-fast-forward refusal", e)
	}
	if resultTestGit(t, remote, nil, "rev-parse", guard.ref) != head {
		t.Fatal("non-fast-forward refusal changed remote")
	}
}

func TestRemotePreparationNativeRetainedPermissionFixture(t *testing.T) {
	root := os.Getenv("MONOS_REMOTE_PREPARATION_EVIDENCE_DIR")
	if root == "" {
		t.Skip("explicit retained evidence directory required")
	}
	if !filepath.IsAbs(root) || publicationDirectory(root) != nil {
		t.Fatal("evidence directory requires safe service-owned private lineage")
	}
	entries, e := os.ReadDir(root)
	if e != nil || len(entries) != 0 {
		t.Fatal("evidence directory must be initially empty", e)
	}
	f, request, _ := publicationPrepareFixture(t)
	publication := filepath.Join(root, "publication")
	pages, e := preparePublicationAt(context.Background(), request, f.export, publication, nil)
	if e != nil || len(pages) != 1 || pages[0].Result.Candidate == nil || pages[0].Result.Scan.Status != "complete" {
		t.Fatal("actual candidate factory unavailable", e)
	}
	candidate := pages[0].Result.Candidate
	store := filepath.Join(root, "public-object-store.git")
	remote := filepath.Join(root, "synthetic-remote.git")
	for _, dir := range []string{store, remote} {
		if publicationDirectory(dir) != nil {
			t.Fatal("private Git directory unavailable")
		}
		resultTestGit(t, dir, nil, "init", "--bare", "--quiet", dir)
	}
	// Copy only the verified public candidate graph into a separate object store;
	// original result export/ref attribution remains intact.
	resultTestGit(t, store, nil, "fetch", "--no-tags", f.export, candidate.Head+":refs/monos/candidates/fixture")
	item, e := lockPublicationRemoteItem(context.Background(), filepath.Join(root, "remote"), "item")
	if e != nil {
		t.Fatal(e)
	}
	defer item.close()
	op, e := item.operationDirectory("push")
	if e != nil {
		t.Fatal(e)
	}
	ref := "refs/heads/synthetic-delivery"
	intent := map[string]any{"schema_version": 1, "operation_id": "push", "item_id": "item", "head": candidate.Head, "tree": candidate.Tree, "ref": ref, "expected_head": nil}
	intentPath := filepath.Join(op, "intent.json")
	if e := savePublicationFile(intentPath, intent); e != nil {
		t.Fatal(e)
	}
	startedPath, workerPath := filepath.Join(op, "started.json"), filepath.Join(op, "worker.json")
	if savePublicationFile(startedPath, map[string]any{"operation_id": "push", "started": true}) != nil {
		t.Fatal("synthetic started intent unavailable")
	}
	guard := publicationPushGuard{candidate.Head, strings.Repeat("0", len(candidate.Head)), ref, remote}
	execution, e := runPublicationGuardedPush(context.Background(), store, op, guard, nil, func(worker publicationRemoteWorker) error {
		return savePublicationFile(workerPath, worker)
	})
	if e != nil || !execution.WorkerAbsent {
		t.Fatal("synthetic primitive push failed", e)
	}
	hooks := filepath.Join(op, "hooks")
	observed := resultTestGit(t, remote, nil, "rev-parse", ref)
	if observed != candidate.Head || resultTestGit(t, f.export, nil, "rev-parse", "refs/monos/result") != request.Source.GitCommit {
		t.Fatal("published graph or original source attribution differs")
	}
	if resultTestGit(t, remote, nil, "rev-list", observed, "--not", f.base) != candidate.Head {
		t.Fatal("private execution ancestry entered synthetic remote")
	}
	result := map[string]any{"schema_version": 1, "operation_id": "push", "request_digest": publicationTestDigest(t, intent), "remote_ref": ref, "observed_head": observed, "worker_absent": execution.WorkerAbsent, "synthetic_primitive_fixture": true}
	resultPath := filepath.Join(op, "result.json")
	if e := savePublicationFile(resultPath, result); e != nil {
		t.Fatal(e)
	}
	type proofPath struct {
		Kind string `json:"kind"`
		Path string `json:"path"`
		Mode string `json:"mode"`
	}
	paths := []proofPath{}
	for _, p := range []struct{ kind, path string }{
		{"root", root}, {"journal", filepath.Join(root, "remote")}, {"item", item.path}, {"operation", op},
		{"intent", intentPath}, {"started", startedPath}, {"worker", workerPath}, {"result", resultPath}, {"lock", filepath.Join(item.path, "lock")},
		{"hooks", hooks}, {"pre_push", filepath.Join(hooks, "pre-push")}, {"public_object_store", store},
		{"synthetic_remote", remote}, {"candidate_intent", filepath.Join(publication, "constructions", request.Construction.ConstructionID, "intent.json")},
		{"candidate_manifest", filepath.Join(publication, "constructions", request.Construction.ConstructionID, "candidate.json")},
		{"scan_pages", filepath.Join(publication, "operations", request.OperationID, "pages.json")},
	} {
		info, e := os.Lstat(p.path)
		if e != nil || info.Mode()&os.ModeSymlink != 0 {
			t.Fatal("proof path unavailable", e)
		}
		paths = append(paths, proofPath{p.kind, p.path, fmt.Sprintf("%04o", info.Mode().Perm())})
	}
	proof := map[string]any{"schema_version": 1, "fixture_scope": "actual_candidate_and_remote_primitives_synthetic_baseline", "service_uid": os.Geteuid(), "operation_id": "push", "item_id": "item", "request_digest": publicationTestDigest(t, intent), "result_digest": publicationTestDigest(t, result), "candidate_manifest_digest": publicationTestDigest(t, candidate), "head": candidate.Head, "tree": candidate.Tree, "remote_ref": ref, "observed_head": observed, "paths": paths}
	if e := savePublicationFile(filepath.Join(root, "proof.json"), proof); e != nil {
		t.Fatal(e)
	}
}
