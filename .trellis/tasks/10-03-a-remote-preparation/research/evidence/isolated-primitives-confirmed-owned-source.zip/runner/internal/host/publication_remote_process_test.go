package host

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"testing"
	"time"
)

// Test-only executable roles exercise real parent/descendant ownership. No
// executable, role or environment selection is exposed by a product protocol.
func TestPublicationRemoteProcessHelper(t *testing.T) {
	switch os.Getenv("MONOS_REMOTE_PROCESS_HELPER") {
	case "parent":
		child := exec.Command(os.Args[0], "-test.run=^TestPublicationRemoteProcessHelper$")
		child.Env = append(publicationGitEnvironment(), "MONOS_REMOTE_PROCESS_HELPER=child")
		child.Stdout, child.Stderr = os.Stdout, os.Stderr
		if child.Start() != nil || os.WriteFile(os.Getenv("MONOS_REMOTE_PROCESS_PID_FILE"), []byte(strconv.Itoa(child.Process.Pid)), 0600) != nil {
			os.Exit(70)
		}
		os.Exit(0) // Deliberately leaves its child and inherited pipes alive.
	case "child":
		time.Sleep(120 * time.Second)
		os.Exit(0)
	case "output":
		_, _ = os.Stdout.Write([]byte(strings.Repeat("x", publicationRemoteOutputLimit+1)))
		time.Sleep(120 * time.Second)
		os.Exit(0)
	case "normal":
		_, _ = os.Stdout.Write([]byte("safe fixture output"))
		os.Exit(0)
	}
}

func publicationProcessFixtureCommand(ctx context.Context, role, pidFile string) *exec.Cmd {
	cmd := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestPublicationRemoteProcessHelper$")
	cmd.Env = append(publicationGitEnvironment(), "MONOS_REMOTE_PROCESS_HELPER="+role, "MONOS_REMOTE_PROCESS_PID_FILE="+pidFile)
	return cmd
}

func TestRemotePreparationProcessGroupCancellationAndParentExit(t *testing.T) {
	for _, cancelConnection := range []bool{false, true} {
		t.Run(fmt.Sprint("cancel_connection_", cancelConnection), func(t *testing.T) {
			root := filepath.Join(publicationTestRoot(t), "remote")
			item, e := lockPublicationRemoteItem(context.Background(), root, "item")
			if e != nil {
				t.Fatal(e)
			}
			defer item.close()
			op, e := item.operationDirectory("operation")
			if e != nil {
				t.Fatal(e)
			}
			intentPath := filepath.Join(op, "intent.json")
			if savePublicationFile(intentPath, map[string]any{"started": true, "operation_id": "operation"}) != nil {
				t.Fatal("started intent unavailable")
			}
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			pidFile := filepath.Join(op, "child.pid")
			childPID := 0
			observedLiveDescendant := false
			started := time.Now()
			out, e := runPublicationRemoteProcess(ctx, func(ctx context.Context) *exec.Cmd { return publicationProcessFixtureCommand(ctx, "parent", pidFile) }, func(worker publicationRemoteWorker) error {
				if e := savePublicationFile(filepath.Join(op, "worker.json"), worker); e != nil {
					return e
				}
				deadline := time.Now().Add(2 * time.Second)
				for time.Now().Before(deadline) {
					raw, e := os.ReadFile(pidFile)
					if e == nil {
						childPID, e = strconv.Atoi(string(raw))
						group, groupErr := syscall.Getpgid(childPID)
						if e == nil && groupErr == nil && group == worker.Group && syscall.Kill(childPID, 0) == nil {
							observedLiveDescendant = true
							if cancelConnection {
								cancel()
							}
							return nil
						}
					}
					time.Sleep(10 * time.Millisecond)
				}
				return fmt.Errorf("controlled descendant not observed")
			})
			if !observedLiveDescendant || childPID <= 1 || e == nil || !out.Started || !out.Interrupted || !out.WorkerAbsent || len(out.Output) != 0 {
				t.Fatalf("parent exit/cancellation manufactured release: %+v error=%v", out, e)
			}
			if syscall.Kill(-out.Worker.Group, 0) != syscall.ESRCH || syscall.Kill(childPID, 0) != syscall.ESRCH {
				t.Fatal("controlled descendant/group survived reported absence")
			}
			if time.Since(started) > 6*time.Second {
				t.Fatal("physical cleanup exceeded bound")
			}
			if _, e := readPublicationFile(intentPath); e != nil {
				t.Fatal("uncertain started intent was lost", e)
			}
			if _, e := os.Lstat(filepath.Join(op, "result.json")); !os.IsNotExist(e) {
				t.Fatal("interruption created a terminal remote result")
			}
		})
	}
}

func TestRemotePreparationProcessOutputBoundAndNormalAbsence(t *testing.T) {
	for _, role := range []string{"normal", "output"} {
		t.Run(role, func(t *testing.T) {
			out, e := runPublicationRemoteProcess(context.Background(), func(ctx context.Context) *exec.Cmd { return publicationProcessFixtureCommand(ctx, role, "") }, nil)
			if !out.Started || !out.WorkerAbsent || syscall.Kill(-out.Worker.Group, 0) != syscall.ESRCH {
				t.Fatal("missing actual group absence")
			}
			if role == "normal" && (e != nil || string(out.Output) != "safe fixture output" || out.Interrupted) {
				t.Fatal("normal fixed process failed", e)
			}
			if role == "output" && (e == nil || len(out.Output) != 0 || !out.Interrupted) {
				t.Fatal("output overflow did not stop ownership", e)
			}
		})
	}
}

func TestRemotePreparationGuardedPushRevalidatesFixedHook(t *testing.T) {
	work, head := scanFixture(t)
	root := publicationTestRoot(t)
	remote := filepath.Join(root, "remote.git")
	resultTestGit(t, root, nil, "init", "--bare", "--quiet", remote)
	guard := publicationPushGuard{head, strings.Repeat("0", len(head)), "refs/heads/delivery", remote}
	hooks, _, e := installPublicationPushGuard(context.Background(), root, guard)
	if e != nil {
		t.Fatal(e)
	}
	if e := os.Chmod(filepath.Join(hooks, "pre-push"), 0600); e != nil {
		t.Fatal(e)
	}
	out, e := runPublicationGuardedPush(context.Background(), scanDir(t, work), root, guard, nil, nil)
	if e == nil || out.Started || !out.WorkerAbsent {
		t.Fatal("Git could silently skip nonexecutable hook")
	}
	if e := os.Chmod(filepath.Join(hooks, "pre-push"), 0700); e != nil {
		t.Fatal(e)
	}
	out, e = runPublicationGuardedPush(context.Background(), scanDir(t, work), root, guard, nil, nil)
	if e != nil || !out.Started || !out.WorkerAbsent || resultTestGit(t, remote, nil, "rev-parse", guard.ref) != head {
		t.Fatal("guarded fixed Git push failed", e)
	}
}
